"""
File: rawMaterials_totalCost.py
Author: Romuald Kinfack 
This Program calculates the total cost of raw materials for 8 hours of work.
"""

from breezypythongui import EasyFrame
from tkinter import PhotoImage, N, S, W, E
from tkinter.font import Font

class rawMaterials_totalCost(EasyFrame):
    """Computes and displays the square root of an input number."""

    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, "Total Cost Raw Materials AFRICOLOR")

        # Label and field for the input
        self.addLabel(text = "Calcium Carbonate",
                      row = 0, column = 0)
        self.inputField = self.addIntegerField(value = 0,
                                               row = 0,
                                               column = 1,
                                               width = 8)

        # Label and field for the output
        self.addLabel(text = "Bentonite",
                      row = 1, column = 0)
        self.inputField1 = self.addFloatField(value = 0.0,
                                              row = 1,
                                              column = 1,
                                              width = 8)
                                              
        self.addLabel(text = "Kaolin",
                      row = 2, column = 0)
        self.inputField2 = self.addFloatField(value = 0.0,
                                              row = 2,
                                              column = 1,
                                              width = 8)
        self.addLabel(text = "Wheat Flour",
                      row = 3, column = 0)
        self.inputField3 = self.addFloatField(value = 0.0,
                                              row = 3,
                                              column = 1,
                                              width = 8)
        self.addLabel(text = "Corn Flour",
                      row = 4, column = 0)
        self.inputField4 = self.addFloatField(value = 0.0,
                                              row = 4,
                                              column = 1,
                                              width = 8)
        self.addLabel(text = "Glue",
                      row = 5, column = 0)
        self.inputField5 = self.addFloatField(value = 0.0,
                                              row = 5,
                                              column = 1,
                                              width = 8)
        self.addLabel(text = "Soap",
                      row = 6, column = 0)
        self.inputField6 = self.addFloatField(value = 0.0,
                                              row = 6,
                                              column = 1,
                                              width = 8)
        self.addLabel(text = "Total Cost",
                      row = 8, column = 0)
        self.outputField = self.addFloatField(value = 0.0,
                                              row = 8,
                                              column = 1,
                                              width = 8,
                                              precision = 2,
                                              state = "readonly")

        

        # The command button
        self.addButton(text = "Compute", row = 7, column = 0,
                       columnspan = 2, command = self.compute)

        # Load the image and associate it with the image label.
        imageLabel = self.addLabel(text = "",
                                   row = 9, column = 1)
        textLabel = self.addLabel(text = "Copyright @ 2023 Africolor. All Rights Reserved",
                                  row = 10, column = 1)
        self.image = PhotoImage(file = "Africolor.png")
        imageLabel["image"] = self.image

    # The event handling method for the button
    def compute(self):
        """Inputs the integer, compute
        and outputs the result."""
        number0 = self.inputField.getNumber()
        result0 = number0*140
        
        number1 = self.inputField1.getNumber()
        result1 = number1*600
        
        number2 = self.inputField2.getNumber()
        result2 = number2*300
        
        number3 = self.inputField3.getNumber()
        result3 = number3*300
        
        number4 = self.inputField4.getNumber()
        result4 = number4*100
        
        number5 = self.inputField5.getNumber()
        result5 = number5*600

        number6 = self.inputField6.getNumber()
        result6 = number6*400
        
        result = result0 + result1 + result2 + result3 + result4 + result5 + result6

        
        # Output the result
        self.outputField.setNumber(result)

       
#Instantiate and pop up the window."""
if __name__ == "__main__":
    rawMaterials_totalCost().mainloop()
