"""
File: productionCost.py
Author: Romuald Kinfack
version 1.3

This program calculates the production costs of a box of 100 bars of school chalk over 8 hours of production.
"""


def calculate_production_cost(raw_material_costs, packaging_costs, others_costs, indirect_costs, quantity):
    total_costs = raw_material_costs + packaging_costs + others_costs + indirect_costs
    production_costs = total_costs / quantity
    return production_costs

def main():
    print("Production Cost Calculator")

    # Get user input for raw_material_costs
    raw_material_costs = float(input("Enter raw_material_costs: Fcfa"))

    # Get user input for packaging_costs
    packaging_costs = float(input("Enter packaging_costs: Fcfa"))

    # Get user input for others_costs
    others_costs = float(input("Enter others_costs: Fcfa"))

    # Get user input for indirect_costs
    indirect_costs = float(input("Enter indirect_costs: Fcfa"))

    # Get user input for quantity
    quantity = float(input("Enter quantity: "))

    # Calculate production costs
    production_cost = calculate_production_cost(raw_material_costs, packaging_costs, others_costs, indirect_costs, quantity)

    # Display the result
    print("\nTotal Production Cost: Fcfa{:.2f}".format(production_cost))

if __name__ == "__main__":
    main()
