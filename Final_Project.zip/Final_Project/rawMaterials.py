"""
File: rawMaterials.py
Author: Romuald Kinfack
version 1.3

This program involves determining the required quantity of raw materials.

1. Calculate and display the other raw materials
from the main raw material, calcium carbonate CaC3.

2.For example, for 8 hours, the production department needs 250 kg of calcium carbonate.
Once this quantity is entered, the program computes and displays the amounts of the other inputs.
So, the different exact values on a formulation will be the following:
Bentonite: 20kg
Kaolin: 2.5kg
Wheat flour: 2.5kg
Corn flour: 7kg
Glue: 1.25kg
Soap: 0.5kg

"""

from breezypythongui import EasyFrame
from tkinter import PhotoImage, N, S, W, E
from tkinter.font import Font
class RawMaterials(EasyFrame):
    """Computes and displays the square root of an input number."""

    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, "Raw Materials AFRICOLOR")

        # Label and field for the input
        self.addLabel(text = "Calcium Carbonate",
                      row = 0, column = 0)
        self.inputField = self.addIntegerField(value = 0,
                                               row = 0,
                                               column = 1,
                                               width = 10)

        # Label and field for the output
        self.addLabel(text = "Bentonite",
                      row = 1, column = 0)
        self.outputField = self.addFloatField(value = 0.0,
                                              row = 1,
                                              column = 1,
                                              width = 8,
                                              precision = 2,
                                              state = "readonly")
        self.addLabel(text = "Kaolin",
                      row = 2, column = 0)
        self.outputField1 = self.addFloatField(value = 0.0,
                                              row = 2,
                                              column = 1,
                                              width = 8,
                                              precision = 2,
                                              state = "readonly")
        self.addLabel(text = "Wheat Flour",
                      row = 3, column = 0)
        self.outputField2 = self.addFloatField(value = 0.0,
                                              row = 3,
                                              column = 1,
                                              width = 8,
                                              precision = 2,
                                              state = "readonly")
        self.addLabel(text = "Corn Flour",
                      row = 4, column = 0)
        self.outputField3 = self.addFloatField(value = 0.0,
                                              row = 4,
                                              column = 1,
                                              width = 8,
                                              precision = 2,
                                              state = "readonly")
        self.addLabel(text = "Glue",
                      row = 5, column = 0)
        self.outputField4 = self.addFloatField(value = 0.0,
                                              row = 5,
                                              column = 1,
                                              width = 8,
                                              precision = 2,
                                              state = "readonly")
        self.addLabel(text = "Soap",
                      row = 6, column = 0)
        self.outputField5 = self.addFloatField(value = 0.0,
                                              row = 6,
                                              column = 1,
                                              width = 8,
                                              precision = 2,
                                              state = "readonly")

        # The command button
        self.addButton(text = "Compute", row = 7, column = 0,
                       columnspan = 2, command = self.compute)

        self.addLabel(text = "Total Quantity",
                      row = 8, column = 0)
        self.outputField = self.addFloatField(value = 0.0,
                                              row = 8,
                                              column = 1,
                                              width = 8,
                                              precision = 2,
                                              state = "readonly")
        
        # Load the image and associate it with the image label.
        imageLabel = self.addLabel(text = "",
                                   row = 9, column = 1)
        textLabel = self.addLabel(text = "Copyright @ 2023 Africolor. All Rights Reserved",
                                  row = 10, column = 1)
        self.image = PhotoImage(file = "Africolor.png")
        imageLabel["image"] = self.image

    # The event handling method for the button
    def compute(self):
        """Inputs the integer, computes 
        and outputs the result."""
        number = self.inputField.getNumber()
        result = number*0.08
        self.outputField.setNumber(result)

        result1 = number*0.01
        self.outputField1.setNumber(result1)

        result2 = number*0.01
        self.outputField2.setNumber(result2)

        result3 = number*0.03
        self.outputField3.setNumber(result3)

        result4 = number*0.005
        self.outputField4.setNumber(result4)

        result5 = number*0.002
        self.outputField5.setNumber(result5)

        result6 = number + result + result1 + result2 + result3 + result4 + result5 

        # Output the result
        self.outputField.setNumber(result6)


        
#Instantiate and pop up the window."""
if __name__ == "__main__":
    RawMaterials().mainloop()
